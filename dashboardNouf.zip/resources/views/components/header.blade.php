<section class="wrapper ">
  <div class="swiper-container swiper-thumbs-container swiper-fullscreen nav-dark" data-margin="0" data-autoplay="true" data-autoplaytime="7000" data-nav="true" data-dots="false" data-items="1" data-thumbs="true" style="border-radius:0px 0px 0px 0px;overflow: hidden;">
    <div class="swiper">
      <div class="swiper-wrapper">
        <div class="swiper-slide bg-overlay bg-overlay-400 bg-dark bg-image" data-image-src="http://alphaco.com.sa/img/bg-default1.jpg"></div>
        <div class="swiper-slide bg-overlay bg-overlay-400 bg-dark bg-image" data-image-src="http://alphaco.com.sa/img/bg-default1.jpg"></div>
        <div class="swiper-slide bg-overlay bg-overlay-400 bg-dark bg-image" data-image-src="http://alphaco.com.sa/img/bg-default1.jpg"></div>
        <div class="swiper-slide bg-overlay bg-overlay-400 bg-dark bg-image" data-image-src="http://alphaco.com.sa/img/bg-default1.jpg"></div>
      </div>
    </div>
    <div class="swiper swiper-thumbs" style="opacity:0">
      <div class="swiper-wrapper">
        <div class="swiper-slide"><img src="http://alphaco.com.sa/img/bg-default1.jpg" srcset="/assets/img/photos/bg28-th@2x.jpg 2x" alt="" /></div>
        <div class="swiper-slide"><img src="http://alphaco.com.sa/img/bg-default1.jpg" srcset="/assets/img/photos/bg29-th@2x.jpg 2x" alt="" /></div>
        <div class="swiper-slide"><img src="http://alphaco.com.sa/img/bg-default1.jpg" srcset="/assets/img/photos/bg30-th@2x.jpg 2x" alt="" /></div>
        <div class="swiper-slide"><img src="http://alphaco.com.sa/img/bg-default1.jpg" srcset="/assets/img/photos/bg31-th@2x.jpg 2x" alt="" /></div>
      </div>
    </div>
    <div class="swiper-static">
      <div class="container h-100 d-flex align-items-center justify-content-center">
        <div class="row">
          <div class="col-lg-12 mx-auto mt-n10 text-center">
            <h2 class="display-1 fs-60 text-white mb-5 animate__animated animate__zoomIn animate__delay-1s font-lg-10" >ألفا للمؤتمرات والمعارض</h2>
            <h1 class="fs-19 text-uppercase ls-xl text-white mb-0 animate__animated animate__zoomIn animate__delay-2s ">شركة وطنية بسمات عالمية بهوية عربية وبروح وثابة مبهرة</h1>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>