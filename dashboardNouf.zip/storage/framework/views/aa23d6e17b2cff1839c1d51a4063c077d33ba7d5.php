
<?php $__env->startSection('content'); ?>
<div class="col-12 p-3">
	<div class="col-12 col-lg-12 p-0 main-box">
	 
		<div class="col-12 px-0">
			<div class="col-12 p-0 row">
				<div class="col-12 col-lg-4 py-3 px-3">
					<span class="fas fa-files"></span> مدير الملفات
				</div>
				<div class="col-12 col-lg-4 p-0">
				</div>
			</div>
			<div class="col-12 divider" style="min-height: 2px;"></div>
		</div>

		<div class="col-12 py-2 px-2 row">
			<div class="col-12 col-lg-4 p-2">
				<form method="GET">
					<input type="text" name="q" class="form-control" placeholder="بحث ... " value="<?php echo e(request()->get('q')); ?>">
				</form>
			</div>
		</div>
		<div class="col-12 p-3" style="overflow:auto">
			<div class="col-12 p-0" style="min-width:1100px;">
				
			
			<table class="table table-bordered  table-hover">
				<thead>
					<tr>
						<th>#</th>
						<th>الرافع</th>
						<th>الملف</th>
						<th>مستخدم في</th> 
						<th>تاريخ الرفع</th> 
						<th>تحكم</th>
					</tr>
				</thead>  
				<tbody>
					<?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($file->id); ?></td>
						<td class="text-truncate" >
							<?php if($file->user_id!=null): ?>
							<img src="<?php echo e($file->user->getUserAvatar()); ?>" style="width:20px;height: 20px;border-radius: 50%;display: inline-block;">
							<?php echo e($file->user->name_ar); ?>

							<?php endif; ?>
						</td>
						<td class="text-truncate d-flex">
							<?php if( in_array($file->extension, ['jpg','jpeg','gif','png','webp'])): ?>
							<div class="col-auto p-1">
							<img src="<?php echo e($file->get_url()); ?>" style="width:60px;display: inline-block;" class="mx-2">
							</div>
							<?php endif; ?>
							<div class="col-auto p-1">
							<a href="<?php echo e($file->get_url()); ?>" style="display: inline-block;" target="_blank">
							 <span class="fas fa-link mx-1"></span>	الرابط
							</a>
							<br>
							<?php if($file->views!=0): ?>
							 <span class="fas fa-search mx-1"></span>	<?php echo e($file->views); ?>

							 <br>
							<?php endif; ?>
							<?php if($file->last_access!=null): ?>
							 <span class="fas fa-clock mx-1"></span>آخر دخول <?php echo e(\Carbon::parse($file->last_access)->diffForHumans()); ?>

							 <br>
							<?php endif; ?>
							 <i class="fas fa-box-open mx-1"></i>	<?php echo e(number_format($file->size / (1024), 2)); ?> KB
							</div>
						</td>
					 
							
							 
						<td><?php echo e($file->type); ?> - <?php echo e($file->type_id); ?></td>
					    <td><?php echo e($file->created_at); ?></td>
						<td style="width: 180px;">

							<?php if (app('laratrust')->isAbleTo('hub-files-read')) : ?>
							<a href="<?php echo e($file->get_url()); ?>" target="_blank">
							<span class="btn  btn-outline-success btn-sm font-1 mx-1 py-1 px-2">
								<span class="fas fa-eye "></span> عرض
							</span>
							</a>
							<?php endif; // app('laratrust')->permission ?>
							<?php if (app('laratrust')->isAbleTo('hub-files-delete')) : ?>
							<form method="POST" action="<?php echo e(route('admin.files.destroy',$file)); ?>" class="d-inline-block"><?php echo csrf_field(); ?> <?php echo method_field("DELETE"); ?>
								<button class="btn  btn-outline-danger btn-sm font-1 mx-1 py-1 px-2" onclick="var result = confirm('هل أنت متأكد من عملية الحذف ؟');if(result){}else{event.preventDefault()}">
									<span class="fas fa-trash "></span> حذف
								</button>
							</form>
							<?php endif; // app('laratrust')->permission ?>
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
			</div>
		</div>
		<div class="col-12 p-3">
			<?php echo e($files->appends(request()->query())->render()); ?>

		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\sites\dashboard\resources\views/admin/files/index.blade.php ENDPATH**/ ?>