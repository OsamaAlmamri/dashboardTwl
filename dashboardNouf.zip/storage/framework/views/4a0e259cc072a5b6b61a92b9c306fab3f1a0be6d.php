<?php
$flat_colors = collect([
'#2196f3',
'#2196f3dd',
'#7cc5ffaa',
'#9ed2fb88',
'#0fb8ff66',
'#5aceff44',
'#8eddff22',
'#c5edff00',
'#c5edff00',
'#c5edff00',
'#c5edff00',
]);
?>
<div class="col-12 p-0">
    <div class="">
        
    </div>
    
    <div class="col-12 row p-0 d-flex">
        <div class="col-12 col-lg-4 p-2">
            
            <div class="col-12 p-0 main-box">
                <div class="col-12 px-0">
                    <div class="col-12 px-3 py-3">
                        إجرائات سريعة
                    </div>
                    <div class="col-12 " style="min-height: 1px;background: var(--border-color);"></div>
                </div>
                <div class="col-12 p-3 row d-flex">
                    <div class="col-4  d-flex justify-content-center align-items-center mb-3 py-2">
                        <a href="<?php echo e(route('home')); ?>" target="_blank" style="color:inherit;">
                            <div class="col-12 p-0 text-center">
                                <img src="/images/icons/house.png" style="width:30px;height: 30px">
                                
                                <div class="col-12 p-0 text-center" >
                                    الموقع
                                </div>
                            </div>
                        </a>
                    </div>
                    <?php if (app('laratrust')->isAbleTo('settings-update')) : ?>
                    <div class="col-4 d-flex justify-content-center align-items-center mb-3 py-2">
                        <a href="<?php echo e(route('admin.settings.index')); ?>" style="color:inherit;">
                            <div class="col-12 p-0 text-center">
                                <img src="/images/icons/settings.png" style="width:30px;height: 30px">
                                
                                <div class="col-12 p-0 text-center" >
                                    الإعدادات
                                </div>
                            </div>
                        </a>
                    </div>
                    <?php endif; // app('laratrust')->permission ?>
                    <div class="col-4 d-flex justify-content-center align-items-center mb-3 py-2">
                        <a href="<?php echo e(route('admin.profile.index')); ?>" style="color:inherit;">
                            <div class="col-12 p-0 text-center">
                                <img src="/images/icons/man.png" style="width:30px;height: 30px">
                                
                                <div class="col-12 p-0 text-center" >
                                    ملفي
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-4 d-flex justify-content-center align-items-center mb-3 py-2">
                        <a href="<?php echo e(route('admin.profile.index')); ?>" style="color:inherit;">
                            <div class="col-12 p-0 text-center">
                                <img src="/images/icons/edit.png" style="width:30px;height: 30px">
                                
                                <div class="col-12 p-0 text-center" >
                                    تعديل ملفي
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-4 d-flex justify-content-center align-items-center mb-3 py-2">
                        <a href="<?php echo e(route('admin.notifications.index')); ?>" style="color:inherit;">
                            <div class="col-12 p-0 text-center">
                                
                                <img src="/images/icons/notification.png" style="width:30px;height: 30px">
                                
                                <div class="col-12 p-0 text-center" >
                                    الإشعارات
                                </div>
                            </div>
                        </a>
                    </div>
                    <?php if (app('laratrust')->isAbleTo('announcements-read')) : ?>
                    <div class="col-4 d-flex justify-content-center align-items-center mb-3 py-2">
                        <a href="<?php echo e(route('admin.announcements.index')); ?>" style="color:inherit;">
                            <div class="col-12 p-0 text-center">
                                
                                <img src="/images/icons/annonce.png" style="width:30px;height: 30px">
                                
                                <div class="col-12 p-0 text-center" >
                                    الإعلانات
                                </div>
                            </div>
                        </a>
                    </div>
                    <?php endif; // app('laratrust')->permission ?>
                    <div class="col-4 d-flex justify-content-center align-items-center mb-3 py-2">
                        <a href="#" onclick="event.preventDefault();document.getElementById('logout-form').submit();" style="color:inherit;">
                            <div class="col-12 p-0 text-center">
                                
                                <img src="/images/icons/logout.png" style="width:30px;height: 30px">
                                
                                <div class="col-12 p-0 text-center" >
                                    خروج
                                </div>
                            </div>
                        </a>
                    </div>


                </div>
            </div>
        </div>
        <?php if (app('laratrust')->isAbleTo('admin-analytics-read')) : ?>


        <div class="col-12 col-lg-4 p-2">
            <div class="col-12 p-0 main-box">
                <div class="col-12 px-0">
                    <div class="col-12 px-3 py-3">
                        <div class="col-12 p-0">
                            <div class="col-12 p-0 row">
                                <div class="col-4">
                                    معدل الزوار

                                    
                                </div>
                                <div class="col-8 d-flex justify-content-end align-items-center">
                                    

                                    <div class="spinner-grow text-info mx-2" role="status" style="width:15px;height: 15px">
                                      <span class="visually-hidden"></span>
                                    </div>

                                    <span style="font-weight: bold;"><?php echo e(count($data['current_visitors'])); ?></span>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    <div class="col-12 " style="min-height: 1px;background: var(--border-color);"></div>
                </div>
                <div class="col-12 p-3">
                    <canvas id="traffics-chart">
                    </canvas>
                </div>
            </div>
        </div>
        <div class="col-12 col-lg-4 p-2">
            <div class="col-12 p-0 main-box">
                <div class="col-12 px-0">
                    <div class="col-12 px-3 py-3">
                        المستخدمين الجدد
                    </div>
                    <div class="col-12 " style="min-height: 1px;background: var(--border-color);"></div>
                </div>
                <div class="col-12 p-3">
                    <canvas id="new-users">
                    </canvas>
                </div>
            </div>
        </div>        <div class="col-12 col-lg-4 p-2">
            <div class="col-12 p-0 main-box">
                <div class="col-12 px-0">
                    <div class="col-12 px-3 py-3">
                        أعلى الصفحات زيارة
                    </div>
                    <div class="col-12 " style="min-height: 1px;background: var(--border-color);"></div>
                </div>
                <div class="col-12 p-3">
                    <?php $__currentLoopData = $data['top_pages']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 px-2 py-1 row">
                        <div class="col-4 p-0">
                            <span style="width: 30px;height: 17px;font-weight: bold;background: #0194fe;color: #fff;" class="badge badge-light d-flex align-items-center justify-content-center">
                                <?php echo e($page->count); ?>

                            </span>
                        </div>
                        <div class="col-8 text-truncate p-0" style="direction:ltr;font-size: 12px;">
                            <a href="<?php echo e($page->url); ?>" target="_blank" style="color:inherit"><?php echo e(urldecode(str_replace(env('APP_URL'),'',$page->url))); ?></a>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="col-12 col-lg-4 p-2">
            <div class="col-12 p-0 main-box" style="min-height:100%">
                <div class="col-12 px-0">
                    <div class="col-12 px-3 py-3">
                        أعلى مصادر الزيارات
                    </div>
                    <div class="col-12 " style="min-height: 1px;background: var(--border-color);"></div>
                </div>
                <div class="col-12 p-3">

                    <?php $__currentLoopData = $data['top_domains']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $main_domain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             
                    <div class="col-12 px-2 py-1 row">
                        <div class="col-4 p-0">
                            <span style="width: 30px;height: 17px;font-weight: bold;background: #0194fe;color: #fff;" class="badge badge-light d-flex align-items-center justify-content-center">
                                <?php echo e($main_domain->domain_count); ?>

                            </span>
                            
                        </div>
                        <div class="col-8 text-truncate p-0" style="direction:ltr;font-size: 12px;">
                            <a href="//<?php echo e($main_domain->main_domain); ?>" target="_blank" style="color:inherit">
                                <img src="https://icons.duckduckgo.com/ip3/<?php echo e($main_domain->main_domain); ?>.ico" style="width:10px;height: 10px;" class="d-inline-block">
                                <?php echo e($main_domain->main_domain); ?>

                            </a>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
                </div>
            </div>
        </div>
        <div class="col-12 col-lg-4 p-2">
            <div class="col-12 p-0 main-box" style="min-height:100%">
                <div class="col-12 px-0">
                    <div class="col-12 px-3 py-3">
                        أعلى الدول وصولاً
                    </div>
                    <div class="col-12 " style="min-height: 1px;background: var(--border-color);"></div>
                </div>
                <div class="col-12 p-3 row">

                    <?php
                    $top_countries_count = $data['top_countries']->sum('count')+0.01;
                    ?>


                    <?php $__currentLoopData = $data['top_countries']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             
                    <div class="col-12 px-2 py-1 row">
                        <div class="col-4 p-0">
                            <span style="width: 30px;height: 17px;font-weight: bold;background: #0194fe;color: #fff;" class="badge badge-light d-flex align-items-center justify-content-center">
                                <?php echo e($country->count); ?>

                            </span>
                            
                        </div>
                        <div class="col-8 text-truncate p-0" style="direction:ltr;font-size: 12px;">
                            
                                <span class="fi fi-<?php echo e(strtolower($country->country_code)); ?> mx-1" style="font-size:10px"></span>
                                <?php echo e($country->country_name); ?>

                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                   
                </div>
            </div>
        </div>
        <div class="col-12 col-lg-4 p-2">
            <div class="col-12 p-0 main-box">
                <div class="col-12 px-0">
                    <div class="col-12 px-3 py-3">
                        المتصفحات
                    </div>
                    <div class="col-12 " style="min-height: 1px;background: var(--border-color);"></div>
                </div>
                <div class="col-12 p-3">
                    <canvas id="ChartBrowsers" style="width:100%;max-height:250px"></canvas>
                </div>
            </div>
        </div>
        <div class="col-12 col-lg-4 p-2">
            <div class="col-12 p-0 main-box">
                <div class="col-12 px-0">
                    <div class="col-12 px-3 py-3">
                        انظمة التشغيل
                    </div>
                    <div class="col-12 " style="min-height: 1px;background: var(--border-color);"></div>
                </div>
                <div class="col-12 p-3">
                    <canvas id="ChartOperatingSystems" style="width:100%;max-height:250px"></canvas>
                </div>
            </div>
        </div>
        <div class="col-12 col-lg-4 p-2">
            <div class="col-12 p-0 main-box">
                <div class="col-12 px-0">
                    <div class="col-12 px-3 py-3">
                        أعلى الأجهزة
                    </div>
                    <div class="col-12 " style="min-height: 1px;background: var(--border-color);"></div>
                </div>
                <div class="col-12 p-3">
                    <canvas id="ChartDevices" style="width:100%;max-height:250px"></canvas>
                </div>
            </div>
        </div>
        <?php endif; // app('laratrust')->permission ?>
    </div>
    <?php $__env->startSection('scripts'); ?>
    <?php if (app('laratrust')->isAbleTo('admin-analytics-read')) : ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <script type="text/javascript">

        new Chart(document.getElementById('traffics-chart').getContext('2d'), {
            type: 'line',
            data: {     
            labels: [
            <?php $__currentLoopData = array_reverse($data['traffics']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            "<?php echo e($key); ?>",
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            datasets: [{
                label: '# معدل الزوار',
                    data: [
                    <?php $__currentLoopData = array_reverse($data['traffics']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    "<?php echo e($value); ?>",
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ],
                        backgroundColor: "#2196f3cc",
                        borderColor: '#2196f3',
                        pointStyle: 'rect',
                        lineTension: '.15',
                        tension: 0.1,
                        fill: true,
                        pointStyle:"circle",
                        pointBorderColor:"#2196f3",
                        pointBackgroundColor:"#fff",
                        pointRadius:4,
                        borderWidth: 3.5,
                }]
            },
            options: {
                responsive:true,
                plugins: {
                    legend: {
                        display:false,
                        labels: {
                            font: {
                                size: 14,
                                family:"kufi-arabic"
                            }
                        }
                    }
                },
                scales: {

                    x: {
                    beginAtZero:false,
                    grid: {
                      display: false
                    }
                  },
                  y: { 
                    grid: {
                      display: true,
                      color:"rgb(3,169,244,0.05)"
                    }
                  },

                },
                hover: {
                    mode: 'index'
                },
                legend: {
                    labels: {

                        fontFamily: 'kufi-arabic',
                        defaultFontFamily: 'kufi-arabic',
                    }
                },
                elements: {
                    line: {
                        tension: 1
                    }
                }
            }
        });





        new Chart(document.getElementById('new-users').getContext('2d'), {
            type: 'line',
            data: {     
            labels: [
            <?php $__currentLoopData = array_reverse($data['new_users']['days_list']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            "<?php echo e($day); ?>",
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            datasets: [{
                label: '# معدل المستخدمين الجدد',
                    data: [
                    <?php $__currentLoopData = array_reverse($data['new_users']['counts_list']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    "<?php echo e($count); ?>",
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ],
                        backgroundColor: "#2196f3cc",
                        borderColor: '#2196f3',
                        pointStyle: 'rect',
                        lineTension: '.15',
                        tension: 0.1,
                        fill: true,
                        pointStyle:"circle",
                        pointBorderColor:"#2196f3",
                        pointBackgroundColor:"#fff",
                        pointRadius:4,
                        borderWidth: 3.5,
                }]
            },
            options: {
                responsive:true,
                plugins: {
                    legend: {
                        display:false,
                        labels: {
                            font: {
                                size: 14,
                                family:"kufi-arabic"
                            }
                        }
                    }
                },
                scales: {

                    x: {
                    beginAtZero:false,
                    grid: {
                      display: false
                    }
                  },
                  y: { 
                    grid: {
                      display: true,
                      color:"rgb(3,169,244,0.05)"
                    }
                  },

                },
                hover: {
                    mode: 'index'
                },
                legend: {
                    labels: {

                        fontFamily: 'kufi-arabic',
                        defaultFontFamily: 'kufi-arabic',
                    }
                },
                elements: {
                    line: {
                        tension: 1
                    }
                }
            }
        });
    const ChartBrowsers = new Chart(document.getElementById('ChartBrowsers'), {
        type: 'doughnut',
        data: {
            labels: [
                <?php $__currentLoopData = $data['top_browsers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $browser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                "<?php echo e($browser->browser); ?>",
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            datasets: [{
                label: 'المتصفحات',
                data: [
                    <?php $__currentLoopData = $data['top_browsers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $browser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    "<?php echo e($browser->count); ?>",
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ],

                backgroundColor: <?php echo json_encode($flat_colors); ?>,
                borderColor: [
                    'transparent',
                ],
                borderWidth: 0
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
    const ChartOperatingSystems = new Chart(document.getElementById('ChartOperatingSystems'), {
        type: 'doughnut',
        data: {
            labels: [
                <?php $__currentLoopData = $data['top_operating_systems']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $os): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                "<?php echo e($os->operating_system); ?>",
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            datasets: [{
                label: 'أنظمة التشغيل',
                data: [
                    <?php $__currentLoopData = $data['top_operating_systems']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $os): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    "<?php echo e($os->count); ?>",
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ],

                backgroundColor: <?php echo json_encode($flat_colors); ?>,
                borderColor: [
                    'transparent',
                ],
                borderWidth: 0
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
    const ChartDevices = new Chart(document.getElementById('ChartDevices'), {
        type: 'doughnut',
        data: {
            labels: [
                <?php $__currentLoopData = $data['top_devices']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                "<?php echo e($device->device); ?>",
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            datasets: [{
                label: 'المتصفحات',
                data: [
                    <?php $__currentLoopData = $data['top_devices']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    "<?php echo e($device->count); ?>",
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ],

                backgroundColor: <?php echo json_encode($flat_colors); ?>,
                borderColor: [
                    'transparent',
                ],
                borderWidth: 0
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    </script>
    <?php endif; // app('laratrust')->permission ?>
    <?php $__env->stopSection(); ?>
</div>
<?php /**PATH E:\sites\dashboardNouf\resources\views/livewire/dashboard-statistics.blade.php ENDPATH**/ ?>