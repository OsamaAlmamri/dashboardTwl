
<?php $__env->startSection('content'); ?>
<div class="col-12 p-3">
	<div class="col-12 col-lg-12 p-0 main-box">
	 
		<div class="col-12 px-0">
			<div class="col-12 p-0 row">
				<div class="col-12 col-lg-4 py-3 px-3">
					<span class="fas fa-users"></span>	المستخدمين
				</div>
				<div class="col-12 col-lg-4 p-0">
				</div>
				<div class="col-12 col-lg-4 p-2 text-lg-end">
					<?php if (app('laratrust')->isAbleTo('users-create')) : ?>
					<a href="<?php echo e(route('admin.users.create')); ?>">
					<span class="btn btn-primary"><span class="fas fa-plus"></span> إضافة جديد</span>
					</a>
					<?php endif; // app('laratrust')->permission ?>
				</div>
			</div>
			<div class="col-12 divider" style="min-height: 2px;"></div>
		</div>

		<div class="col-12 py-2 px-2 row">
			<div class="col-12 col-lg-4 p-2">
				<form method="GET">
					<input type="text" name="q" class="form-control" placeholder="بحث ... " value="<?php echo e(request()->get('q')); ?>">
				</form>
			</div>
		</div>
		<div class="col-12 p-3" style="overflow:auto">
			<div class="col-12 p-0" style="min-width:1100px;">
				
			
			<table class="table table-bordered  table-hover">
				<thead>
					<tr>
						<th>#</th>
						<th>الاسم</th>
						<th>البريد</th>
						<th>تحكم</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($user->id); ?></td>
						<td><?php echo e($user->name); ?></td>
						<td><?php echo e($user->email); ?></td>
						<td>
							<?php if (app('laratrust')->isAbleTo('users-read')) : ?>
							<a href="<?php echo e(route('admin.users.show',$user)); ?>">
							<span class="btn  btn-outline-primary btn-sm font-1 mx-1">
								<span class="fas fa-search "></span> عرض
							</span>
							</a>
							<?php endif; // app('laratrust')->permission ?>

							
							

							<?php if (app('laratrust')->isAbleTo('notifications-create')) : ?>
							<a href="<?php echo e(route('admin.notifications.index',['user_id'=>$user->id])); ?>">
							<span class="btn  btn-outline-primary btn-sm font-1 mx-1">
								<span class="far fa-bells"></span> الاشعارات
							</span>
							</a>
							<a href="<?php echo e(route('admin.notifications.create',['user_id'=>$user->id])); ?>">
							<span class="btn  btn-outline-primary btn-sm font-1 mx-1">
								<span class="far fa-bell"></span>
							</span>
							</a> 
							<?php endif; // app('laratrust')->permission ?>

							<?php if (app('laratrust')->isAbleTo('user-roles-update')) : ?>
							<a href="<?php echo e(route('admin.users.roles.index',$user)); ?>">
							<span class="btn btn-outline-primary btn-sm font-1 mx-1">
								<span class="fal fa-key "></span> الصلاحيات
							</span>
							</a>
							<?php endif; // app('laratrust')->permission ?>
							
							<?php if (app('laratrust')->isAbleTo('users-update')) : ?>
							<a href="<?php echo e(route('admin.users.edit',$user)); ?>">
							<span class="btn  btn-outline-success btn-sm font-1 mx-1">
								<span class="fas fa-wrench "></span> تحكم
							</span>
							</a>
							<?php endif; // app('laratrust')->permission ?>
							<?php if (app('laratrust')->isAbleTo('users-delete')) : ?>
							<form method="POST" action="<?php echo e(route('admin.users.destroy',$user)); ?>" class="d-inline-block"><?php echo csrf_field(); ?> <?php echo method_field("DELETE"); ?>
								<button class="btn  btn-outline-danger btn-sm font-1 mx-1" onclick="var result = confirm('هل أنت متأكد من عملية الحذف ؟');if(result){}else{event.preventDefault()}">
									<span class="fas fa-trash "></span> حذف
								</button>
							</form>
							<?php endif; // app('laratrust')->permission ?>
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
			</div>
		</div>
		<div class="col-12 p-3">
			<?php echo e($users->appends(request()->query())->render()); ?>

		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\sites\dashboard\resources\views/admin/users/index.blade.php ENDPATH**/ ?>