<footer class="card pt-5">
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


    <div class="container pb-12 text-center">
        <div class="row mb-3">
            <div class="col-xl-5 col-lg-5 col-md-12 col-sm-12 col-xs-12">
                <div class="f_widget company_widget infocompany">
                    <a href="#" class="f-logo">
                        <img alt="" src="<?php echo e($settings->website_logo()); ?>"
                             srcset="<?php echo e($settings->website_logo()); ?>">

                        <div class="widget-wrap">
                            <h4 class="header_footer_bottom" dir="rtl">
                                <?php echo e($settings->footer_about); ?>


                            </h4>


                        </div>

                    </a></div>
                <a href="http://tatbeqakum.test" class="f-logo">
                </a></div>

            <div class="col-xl-4 col-lg-4 col-md-5 col-sm-5 col-xs-12"><a href="http://tatbeqakum.test"
                                                                          class="f-logo">
                </a>
                <div class="f_widget about-widget"><a href="http://tatbeqakum.test" class="f-logo">
                        <h3 class="f-title f_600 sm:my-5 t_color f_size_25 mb_40">تواصل معنا</h3>
                    </a>
                    <div class="pp_contact_info"><a href="http://tatbeqakum.test" class="f-logo">
                            <div class="media pp_contact_item">
                                <div class="mmedia-body">
                                    <address>
                                        <p>
                                            <?php echo e($settings->address); ?>

                                            &nbsp;
                                        </p>
                                    </address>
                                </div>


                            </div>
                        </a>
                        <div class="media pp_contact_item"><a href="http://tatbeqakum.test" class="f-logo">


                            </a>
                            <div class="mmedia-body"><a href="http://tatbeqakum.test" class="f-logo">
                                </a><a href="mailto:<?php echo e($settings->contact_email); ?>"><?php echo e($settings->contact_email); ?></a>
                                <?php if($settings->email2!=null): ?>
                                    <a href="mailto:<?php echo e($settings->email2); ?>"><?php echo e($settings->email2); ?></a>
                                <?php endif; ?>
                                <?php if($settings->email3!=null): ?>
                                    <a href="mailto:<?php echo e($settings->email3); ?>"><?php echo e($settings->email3); ?></a>
                                <?php endif; ?>
                            </div>
                        </div>










                    </div>

                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-5 col-sm-5 col-xs-12">
                <div class="f_widget about-widget pl_40">
                    <h3 class="f-title f_600 t_color f_size_25 mb_40">روابط سريعة</h3>
                    <ul class="list-unstyled f_list">
                        <li><a href="#index">الرئيسية</a></li>

                        <li><a href="#">الاعمال</a></li>
                        <li><a href="#">تواصل معنا</a></li>

                    </ul>
                </div>
            </div>


        </div>
        <div class="row mt-n10 mt-lg-0">
            <div class="col-xl-10 mx-auto">


                
                
                
                
                
                
                
                

                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                <!--/.row -->

                <div class="row md:mt-5 ">


                <nav class="col-12 col-md-6 nav social  justify-content-center">
                    <?php if($settings->twitter_link!=null): ?>
                        <a href="<?php echo e($settings->twitter_link); ?>"><i class="fab fa-twitter"></i></a>
                    <?php endif; ?>
                    <?php if($settings->facebook_link!=null): ?>
                        <a href="<?php echo e($settings->facebook_link); ?>"><i class="fab fa-facebook-f"></i></a>
                    <?php endif; ?>
                    <?php if($settings->instagram_link!=null): ?>
                        <a href="<?php echo e($settings->instagram_link); ?>"><i class="fab fa-instagram"></i></a>
                    <?php endif; ?>
                    <?php if($settings->youtube_link!=null): ?>
                        <a href="<?php echo e($settings->youtube_link); ?>"><i class="fab fa-youtube"></i></a>
                    <?php endif; ?>
                    <?php if($settings->whatsapp_link!=null): ?>
                        <a href="<?php echo e($settings->whatsapp_link); ?>"><i class="fab fa-whatsapp"></i></a>
                    <?php endif; ?>
                </nav>

                <p class=" col-12 col-md-6 text-center">

                    برمجة وتطوير <a href="http://tatbeqakum.com" target="_blank">تطبيقكم</a>

                    © <?php echo e(date('Y')); ?>

                </p>
                </div>
                <!-- /.social -->
            </div>
            <!-- /column -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container -->
</footer>
<?php /**PATH E:\sites\dashboardNouf\resources\views/components/footer.blade.php ENDPATH**/ ?>