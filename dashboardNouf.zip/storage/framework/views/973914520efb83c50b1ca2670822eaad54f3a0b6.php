<?php $__env->startSection('content'); ?>
<div class="col-12 p-0  bg-light pt-6">

	<section class="section-frame overflow-hidden">
	      <div class="wrapper bg-soft-primary">
	        <div class="container py-12 py-md-10 text-center">
	          <div class="row">
	            <div class="col-md-7 col-lg-6 col-xl-5 mx-auto">
	              <h1 class="display-1 mb-3 text-center">المدونة</h1>
	              <p class="lead px-lg-5 px-xxl-8 mb-1 text-center">إليك أحدث مقالاتنا.</p>
	            </div>
	            <!-- /column -->
	          </div>
	          <!-- /.row -->
	        </div>
	        <!-- /.container -->
	      </div>
	      <!-- /.wrapper -->
	    </section>


	<div class=" p-0 container mb-15 py-10 " style="min-height:70vh">
		<div class="col-12 p-2 p-lg-3 row">

			<div class="col-12 p-2 row">
				<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


				<div class="col-12 col-lg-4 mb-4">
		            <article>
		              <div class="card shadow-lg">
		                <figure class="card-img-top overlay overlay-1"><a href="<?php echo e(route('article.show',$article)); ?>"> <img src="<?php echo e($article->main_image()); ?>" alt="" style="height:280px !important;object-fit: cover;vertical-align: middle;" /></a>
		                  <figcaption>
		                    <h5 class="from-top mb-0 text-center">عرض المزيد</h5>
		                  </figcaption>
		                </figure>
		                <div class="card-body p-6">
		                  <div class="post-header">
		                    <div class="post-category">
		                    	<?php $__currentLoopData = $article->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                    	<?php if($loop->index<3): ?>
			                    		<a href="<?php echo e(route('category.show',$article_category)); ?>" class="hover" rel="category"><?php echo e($article_category->title); ?></a>
			                    	<?php endif; ?>
		                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		                    </div>
		                    <h2 class="post-title h3 mt-1 mb-3"><a class="link-dark" href="<?php echo e(route('article.show',$article)); ?>"><?php echo e($article->title); ?></a></h2>
		                  </div>
		                  <div class="post-footer">
		                    <ul class="post-meta d-flex mb-0">
		                      <li class="post-date">
		                      	<span>
		                      		<i class="fal fa-clock"></i>  <?php echo e(\Carbon::parse($article->created_at)->diffForHumans()); ?>

		                      	</span>
		                      </li>
		                      <?php if($article->comments_count==null || $article->comments_count ==0): ?>
		                      <li class="post-comments"><a href="#">  <?php echo e($article->comments_count); ?> <i class="fal fa-comment"></i> </a></li>
		                      <?php endif; ?>
		                    </ul>
		                  </div>
		                </div>
		              </div>
		            </article>
		          </div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				<div class="col-12 p-2">
					<?php echo e($articles->links()); ?>

				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app',['page_title'=>"المدونة"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\sites\dashboard\resources\views/front/pages/blog.blade.php ENDPATH**/ ?>