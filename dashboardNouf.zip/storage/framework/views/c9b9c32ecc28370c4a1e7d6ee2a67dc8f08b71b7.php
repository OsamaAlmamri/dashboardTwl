
<?php $__env->startSection('content'); ?>
<div class="col-12 p-3">
    <div class="col-12 col-lg-12 p-0 ">
        <form id="validate-form" class="row" enctype="multipart/form-data" method="POST" action="<?php echo e(route('admin.faqs.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="col-12 col-lg-8 p-0 main-box">
                <div class="col-12 px-0">
                    <div class="col-12 px-3 py-3">
                        <span class="fas fa-info-circle"></span> إضافة جديد
                    </div>
                    <div class="col-12 divider" style="min-height: 2px;"></div>
                </div>
                <div class="col-12 p-3 row">
             
                    
                    <div class="col-12 col-lg-12 p-2">
                        <div class="col-12">
                            السؤال
                        </div>
                        <div class="col-12 pt-3">
                            <input type="text" name="question" required maxlength="190" class="form-control" value="<?php echo e(old('question',$level??"")); ?>">
                        </div>
                    </div>
                    <div class="col-12 col-lg-12 p-2">
                        <div class="col-12">
                            الجواب
                        </div>
                        <div class="col-12 pt-3">
                            <textarea name="answer" class="form-control" style="min-height:150px"><?php echo e(old('answer',$level??"")); ?></textarea>
                        </div>
                    </div>
                    <div class="col-12 p-2">
                        <div class="col-12">
                            مميز
                        </div>
                        <div class="col-12 pt-3">
                            <select class="form-control" name="is_featured">
                                <option <?php if(old('is_featured',$level??"")=="0" ): ?> selected <?php endif; ?> value="0">لا</option>
                                <option <?php if(old('is_featured',$level??"")=="1" ): ?> selected <?php endif; ?> value="1">نعم</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 p-3">
                <button class="btn btn-success" id="submitEvaluation">حفظ</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\sites\dashboard\resources\views/admin/faqs/create.blade.php ENDPATH**/ ?>