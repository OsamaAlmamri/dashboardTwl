
<?php $__env->startSection('content'); ?>
<style type="text/css">
	.article img,iframe{
		max-width: 100%;
	}
  pre[class*=language-]{
    background: #24292e!important;
    border-radius: 10px!important;
  }
  code[class*=language-],code *{
    font-family: monospace!important;
  }
  code[class*=language-], pre[class*=language-]{
    white-space: pre!important;
  }
  .token.class-name, .token.constant, .token.property, .token.symbol {
      color: #79b8f2!important;
  }
  .token.entity, .token.operator, .token.url{
    color: #F97583!important;
  }
  .token.attr-value, .token.char, .token.regex, .token.string, .token.variable{
    color: #9ECBFF!important;
  }
  .token.boolean, .token.function, .token.number{
    color: #B392F0!important;
  }

</style>
<section class="wrapper bg-soft-primary">
      <div class="container pt-10 pb-19 pt-md-14 pb-md-20 text-center">
        <div class="row">
          <div class="col-md-10 col-xl-8 mx-auto">
            <div class="post-header">
              <div class="post-category text-line">

              	<?php $__currentLoopData = $article->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                	<?php if($loop->index<5): ?>
                		<a href="<?php echo e(route('category.show',$article_category)); ?>" class="hover pe-2" rel="category"><?php echo e($article_category->title); ?></a>
                	<?php endif; ?>
            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <!-- /.post-category -->
              <h1 class="display-1 mb-4"><?php echo e($article->title); ?></h1>
              <ul class="post-meta mb-5">
                <li class="post-date font-1"><i class="fal fa-calendar-alt"></i><span> <?php echo e(\Carbon::parse($article->created_at)->diffForHumans()); ?></span></li>
                <li class="post-author font-1"><a href="<?php echo e(route('blog',['user_id'=>$article->user->id])); ?>" class="font-1"><i class="fal fa-user"></i><span> <?php echo e($article->user->name); ?></span></a></li>
                <?php if($article->comments_count!=0): ?>
                <li class="post-comments"><a href="#comments"><i class="fal fa-comment"></i> <?php echo e($article->comments_count); ?><span> تعليقات</span></a></li>
                <?php endif; ?>
                <?php if($article->views!=0): ?>
                <li class="post-comments"><a href="#comments"><i class="fas fa-fa-thin fa-eyes"></i> <?php echo e($article->views); ?><span> مشاهدة</span></a></li>
                <?php endif; ?>
                
              </ul>

              <div class="post-category text-line">
              	<?php $__currentLoopData = $article->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article_tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                	<?php if($loop->index<5): ?>
                		<a href="<?php echo e(route('tag.show',$article_tag)); ?>" class="hover pe-2" rel="tag">#<?php echo e($article_tag->tag_name); ?></a>
                	<?php endif; ?>
            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>

              <!-- /.post-meta -->
            </div>
            <!-- /.post-header -->
          </div>
          <!-- /column -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container -->
    </section>
    <!-- /section -->
    <section class="wrapper bg-light article">
      <div class="container pb-14 pb-md-16 px-0">
        <div class="row">
          <div class="col-lg-10 mx-auto">
            <div class="blog single mt-n17">
              <div class="card">
                <figure class="card-img-top"><img src="<?php echo e($article->main_image()); ?>" alt="" /></figure>
                <div class="card-body p-4 p-lg-9">
                  <div class="classic-view">
                  	<article class="post">
                  		<?php echo $article->description; ?>

                  	</article>
                    <!-- /.post -->
                  </div>
                  <!-- /.classic-view -->
                  <hr />
                  <div class="col-12 p-0 text-center">
                  	
                  
                  <div class="author-info d-md-flex align-items-center mb-3 text-center col-12">
                    <div class="d-flex align-items-center row mx-auto">
                    	<div class="col-12 text-center d-flex align-items-center justify-content-center ">
                    		<figure class="user-avatar m-0"><a href="<?php echo e(route('blog',['user_id'=>$article->user->id])); ?>" class="link-dark font-1"><img class="rounded-circle m-0" alt="" src="<?php echo e($article->user->getUserAvatar()); ?>" /></a></figure>
                    	</div>
                      	<div class="col-12 text-center d-flex align-items-center justify-content-center">
                     
                    
                        <h6><a href="<?php echo e(route('blog',['user_id'=>$article->user->id])); ?>" class="link-dark font-1"><?php echo e($article->user->name); ?></a></h6>
                      
                  </div>
                    </div>
                  </div>
                  </div>
                  <!-- /.author-info -->
                  <p class="text-center"><?php echo e($article->user->bio); ?>.</p>

                  <?php if($article->comments_count): ?>
                  <hr />
                  <div id="comments">
                    <h3 class="mb-6"><?php echo e($article->comments_count); ?> التعليقات</h3>
                    <ol id="singlecomments" class="commentlist">
                    	<?php $__currentLoopData = $article->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li class="comment">
                        <div class="comment-header d-md-flex align-items-center">
                          <div class="d-flex align-items-center">

                            <figure class="user-avatar ms-2 me-0"><img class="rounded-circle" alt="" src="<?php echo e($comment->user==null?env('DEFAULT_IMAGE_AVATAR'):$comment->user->getUserAvatar()); ?>" style="width:40px;height:40px" /></figure>

                            <div>
                              <h6 class="comment-author"><a href="#" class="link-dark font-1"><?php echo e($comment->user==null?$comment->adder_name:$comment->user->name); ?></a></h6>
                              <ul class="post-meta">
                                <li><i class="fal fa-calendar-alt"></i> <?php echo e(\Carbon::parse($comment->created_at)->diffForHumans()); ?></li>
                              </ul>
                            </div>
                          </div>
                          
                        </div>
                        <p><?php echo e($comment->content); ?></p>
                      </li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ol>
                  </div>
                  <hr />
                  <?php endif; ?>
                
                  <h3 class="mb-3">شاركنا رأيك</h3>
                  <p class="mb-7">بريدك الالكتروني لن يتم نشره.</p>
                  <form class="comment-form" method="POST" action="<?php echo e(route('comment-post')); ?>">
                  	<?php echo csrf_field(); ?>
                  	<input type="hidden" name="article_id" value="<?php echo e($article->id); ?>">
                  	<?php if(auth()->guard()->guest()): ?>
                    <div class="form-floating mb-4">
                      <input type="text" class="form-control" placeholder="الاسم*" id="c-name" name="adder_name">
                      <label for="c-name">الاسم *</label>
                    </div>
                    <div class="form-floating mb-4">
                      <input type="email" class="form-control" placeholder="البريد الإلكتروني*" id="c-email" name="adder_email">
                      <label for="c-email">البريد الإلكتروني*</label>
                    </div>
                    <?php endif; ?>
                    <div class="form-floating mb-4">
                      <textarea name="content" class="form-control" placeholder="تعليقك" style="height: 150px"></textarea>
                      <label>تعليقك *</label>
                    </div>
                    <button type="submit" class="btn btn-primary rounded-pill mb-0">اضافة تعليق</button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
	Fancybox.bind('.post img', {
	  caption: function (fancybox, carousel, slide) {
	    return (
	      `${slide.index + 1} / ${carousel.slides.length} <br />` + slide.caption
	    );
	  },
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app',['page_title'=>$article->title,'page_description'=>$article->meta_description,'page_image'=>$article->main_image()], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\sites\dashboardNouf\resources\views/front/pages/article.blade.php ENDPATH**/ ?>