<section class="wrapper bg-light">
  <div class="container py-14 py-md-16">
    <div class="row gx-lg-8 gx-xl-12 gy-10 align-items-center">
      <div class="col-lg-6 position-relative order-lg-2">
        <div class="shape bg-dot primary rellax w-16 h-20" data-rellax-speed="1" style="top: 3rem; left: 5.5rem"></div>
        <div class="overlap-grid overlap-grid-2">
          <div class="item">
            <figure class="rounded shadow"><img src="./assets/img/logo (1).png"
                                                srcset="./assets/img/logo (1).png" alt=""></figure>
          </div>



        </div>
      </div>
      <!--/column -->
      <div class="col-lg-6">

        <h2 class="display-4 mb-3">
          
          <span class="far fa-info-circle" style="color:#0194fe"></span>
           من نحن؟</h2>
        <p class="lead fs-lg">
            تعريف عن تطبيقكم
            </p>
        <p class="mb-6">
            نخن محرك إبداعي متميز , نرتقي بأعمال شركائنا وهوياتهم التجارية في فضاء الإعلام الرقمي المعاصر , ويدفعنا الشغف والإبداع لنخلق حلولا جذابة تضع اعمالهم في مكانها الذي تستحقة , كـ نجم في فظاء الإعلام الرقمي
        </p>























































        <!--/.row -->
      </div>
      <!--/column -->
    </div>
    <!--/.row -->
  </div>
  <!-- /.container -->
</section>
<?php /**PATH E:\sites\dashboard\resources\views/components/about.blade.php ENDPATH**/ ?>