<div class="pp-scrollable bg-grey p-table section section2 callaction_area section-2 pp-section active" data-page-index="2" style="z-index: 10;">

    <div class="scroll-wrap">



        <div class="scrollable-content" dir="rtl">

            <div class="round_line three"></div>

            <div class="container shadowcustom callaction">

                <div class="row align-items-center">
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-xs-12">
                        <img src="/assets/img/haveuproject.png">
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-xs-12">

                        <div class="h_promo_content text-center">
                            <h2>راسلنا واحنا الها </h2>
                            <p>ارسل لنا تفاصيل المشروع</p>
                        </div>
                    </div>

                                    <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-xs-12 text-center">






                                        <button type="button" class="btn btn-primary rounded"
                                                data-bs-toggle="modal" data-bs-target="#exampleModal">
                                            ارسل المشروع
                                        </button>
                    </div>
                </div>

            </div>

            <div class="round-custom"></div>
            <div class="round-custom_1"></div>



        </div>
    </div>
</div>

<?php echo $__env->make('components/ModalRequest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH E:\sites\dashboard\resources\views/components/has_project.blade.php ENDPATH**/ ?>