<section class="wrapper bg-light">
    <div class="container py-14 py-md-16">
        
        
        
        
        
        <div class="position-relative">
            <div class="shape rounded-circle bg-soft-yellow rellax w-16 h-16" data-rellax-speed="1"
                 style="bottom: 0.5rem; right: -1.7rem;"></div>
            <div class="shape rounded-circle bg-line red rellax w-16 h-16" data-rellax-speed="1"
                 style="top: 0.5rem; left: -1.7rem;"></div>
            <div class="swiper-container dots-closer mb-6" data-margin="0" data-dots="true" data-items-xxl="1"
                 data-items-lg="1" data-items-md="1" data-items-xs="1">
                <div class="swiper">
                    <div class="swiper-wrapper">


                        <?php $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="swiper-slide">
                                <div class="item-inner">

                                    
                                    
                                    
                                    
                                    <div class="card p-0">
                                        <div class="row" >

                                            <div
                                                class="slidet_content col-xl-7 col-lg-7 col-md-7 col-sm-6 col-xs-12">
                                                <h2>  <?php echo e($announcement->title); ?></h2>
                                                <p> <?php echo $announcement->description; ?></p>





                                                <?php if($announcement->url!=null): ?>
                                                <a
                                                    style="z-index: 999999"
                                                    href="<?php echo e($announcement->url); ?>" data-toggle="modal"

                                                    target="<?php echo e($announcement->open_url_in=='NEW_WINDOW'?'_blank':'_self'); ?>"
                                                   data-target="#exampleModal" class="slider_btn btn_hover">
                                                    عرض المزيد

                                                </a>
                                                    <?php endif; ?>
                                            </div>
                                            <div class="image_mockup col-xl-5 col-lg-5 col-md-5 col-sm-6 col-xs-12">
                                                <div class="container-image">

                                                    <img class="p-2 watch" src="<?php echo e($announcement->image()); ?>" alt=""
                                                         data-fancybox="gallery"/>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH E:\sites\dashboard\resources\views/components/slider2.blade.php ENDPATH**/ ?>