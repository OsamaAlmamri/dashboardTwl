<section class="wrapper bg-light ">
  <div class="container py-5 py-md-6 ">
    <h2 class="display-4 mb-3 text-center mt-2">الأسئلة الشائعة</h2>
    <p class=" text-center mb-10 px-md-16 px-lg-0" >نرد على الاستفسارات الخاصة بكم في صورة سؤال وجواب.</p>
    <div class="row">
      <div class="col-lg-12 mb-0">
        <div id="accordion-1" class="accordion-wrapper">
          <?php
          $faqs = \App\Models\Faq::orderBy('order','DESC')->get();
          ?>
          <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="card accordion-item col-lg-12">
            <div class="card-header" id="accordion-heading-<?php echo e($faq->id); ?>">
              <button class="collapsed" data-bs-toggle="collapse" data-bs-target="#accordion-collapse-<?php echo e($faq->id); ?>" aria-expanded="false" aria-controls="accordion-collapse-<?php echo e($faq->id); ?>" style="text-align: start; color: #f7ad42"><?php echo e($faq->question); ?></button>
            </div>
            <!-- /.card-header -->
            <div id="accordion-collapse-<?php echo e($faq->id); ?>" class="collapse" aria-labelledby="accordion-heading-<?php echo e($faq->id); ?>" data-bs-target="#accordion-1">
              <div class="card-body">
                <p><?php echo e($faq->answer); ?></p>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.collapse -->
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <!-- /.accordion-wrapper -->
      </div>
      <!--/column -->

      <!--/column -->
    </div>
    <!--/.row -->
  </div>
  <!-- /.container -->
</section>
<!-- /section -->
<?php /**PATH E:\sites\dashboardNouf\resources\views/components/faqs.blade.php ENDPATH**/ ?>