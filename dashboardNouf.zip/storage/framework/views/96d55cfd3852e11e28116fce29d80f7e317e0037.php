<?php $__env->startSection('content'); ?>
<div class="col-12 p-3">
	<div class="col-12 col-lg-12 p-0 main-box">

		<div class="col-12 px-0">
			<div class="col-12 p-0 row">
				<div class="col-12 col-lg-4 py-3 px-3">
					<span class="fas fa-articles"></span> اعمالنا
				</div>
				<div class="col-12 col-lg-4 p-0">
				</div>
				<div class="col-12 col-lg-4 p-2 text-lg-end">
					<?php if (app('laratrust')->isAbleTo('articles-create')) : ?>
					<a href="<?php echo e(route('admin.articles.create')); ?>">
						<span class="btn btn-primary"><span class="fas fa-plus"></span> إضافة جديد</span>
					</a>
					<?php endif; // app('laratrust')->permission ?>
				</div>
			</div>
			<div class="col-12 divider" style="min-height: 2px;"></div>
		</div>

		<div class="col-12 py-2 px-2 row">
			<div class="col-12 col-lg-4 p-2">
				<form method="GET">
					<input type="text" name="q" class="form-control" placeholder="بحث ... " value="<?php echo e(request()->get('q')); ?>">
				</form>
			</div>
		</div>
		<div class="col-12 p-3" style="overflow:auto">
			<div class="col-12 p-0" style="min-width:1100px;">


			<table class="table table-bordered  table-hover">
				<thead>
					<tr>
						<th>#</th>
						<th>المستخدم</th>
						
						<th>الرابط</th>
						<th>الشعار</th>
						<th>العنوان</th>
						<th>مميز</th>
						<th>تحكم</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($article->id); ?></td>
						<td><?php echo e($article->user->name); ?></td>
						
						<td><?php echo e($article->slug); ?></td>
						<td><img src="<?php echo e($article->main_image()); ?>" style="width:40px"></td>
						<td><?php echo e($article->title); ?></td>
						<td>
							<?php if($article->is_featured==1): ?>
							<span class="fas fa-check-circle text-success" ></span>
							<?php endif; ?>
						</td>
						<td style="width: 360px;">




							<?php if (app('laratrust')->isAbleTo('articles-read')) : ?>
							<a href="<?php echo e(route('article.show',['article'=>$article])); ?>">
								<span class="btn  btn-outline-primary btn-sm font-1 mx-1">
									<span class="fas fa-search "></span> عرض
								</span>
							</a>
							<?php endif; // app('laratrust')->permission ?>

							<?php if (app('laratrust')->isAbleTo('comments-read')) : ?>
							<a href="<?php echo e(route('admin.article-comments.index',['article_id'=>$article->id])); ?>">
								<span class="btn  btn-outline-primary btn-sm font-1 mx-1">
									<span class="fas fa-comments "></span> التعليقات
								</span>
							</a>
							<?php endif; // app('laratrust')->permission ?>

							<?php if (app('laratrust')->isAbleTo('articles-update')) : ?>
							<a href="<?php echo e(route('admin.articles.edit',$article)); ?>">
								<span class="btn  btn-outline-success btn-sm font-1 mx-1">
									<span class="fas fa-wrench "></span> تحكم
								</span>
							</a>
							<?php endif; // app('laratrust')->permission ?>
							<?php if (app('laratrust')->isAbleTo('articles-delete')) : ?>
							<form method="POST" action="<?php echo e(route('admin.articles.destroy',$article)); ?>" class="d-inline-block"><?php echo csrf_field(); ?> <?php echo method_field("DELETE"); ?>
								<button class="btn  btn-outline-danger btn-sm font-1 mx-1" onclick="var result = confirm('هل أنت متأكد من عملية الحذف ؟');if(result){}else{event.preventDefault()}">
									<span class="fas fa-trash "></span> حذف
								</button>
							</form>
							<?php endif; // app('laratrust')->permission ?>
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
			</div>
		</div>
		<div class="col-12 p-3">
			<?php echo e($articles->appends(request()->query())->render()); ?>

		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\sites\dashboardNouf\resources\views/admin/articles/index.blade.php ENDPATH**/ ?>