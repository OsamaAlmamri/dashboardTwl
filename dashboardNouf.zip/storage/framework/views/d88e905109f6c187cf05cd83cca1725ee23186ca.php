
<?php $__env->startSection('content'); ?>
<style type="text/css">
	.ticket-resolved{
		background: #effff0!important;
	}
</style>
<div class="col-12 p-3">
	<div class="col-12 col-lg-12 p-0 main-box">
	 
		<div class="col-12 px-0">
			<div class="col-12 p-0 row">
				<div class="col-12 col-lg-4 py-3 px-3">
					<span class="fas fa-contacts"></span> الاتصالات
				</div>
				<div class="col-12 col-lg-4 p-0">
				</div>
			</div>
			<div class="col-12 divider" style="min-height: 2px;"></div>
		</div>

		<div class="col-12 py-2 px-2 row">
			<div class="col-12 col-lg-4 p-2">
				<form method="GET">
					<input type="text" name="q" class="form-control" placeholder="بحث ... " value="<?php echo e(request()->get('q')); ?>">
				</form>
			</div>
		</div>
		<div class="col-12 p-3" style="overflow:auto">
			<div class="col-12 p-0" style="min-width:1100px;">
				
			
			<table class="table table-bordered  table-hover">
				<thead>
					<tr>
						<th>#</th>
						<?php if (app('laratrust')->isAbleTo('contacts-update')) : ?>
						<th scope="col" style="width:40px;">تم</th>
						<?php endif; // app('laratrust')->permission ?>
						<th>المستخدم</th>
						<th>محتوى التذكرة</th>
						<th>تحكم</th>
					</tr>
				</thead>  
				<tbody>
					<?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr 
					id="ticket_<?php echo e($contact->id); ?>"
					class="<?php if($contact->status=="DONE"): ?> ticket-resolved <?php endif; ?>" 
					 >
						<td><?php echo e($contact->id); ?></td>
						<?php if (app('laratrust')->isAbleTo('contacts-update')) : ?>
						<td scope="col" style="width:30px;">
		      
					      	<div class="form-switch">
							  <input class="form-check-input toggle-contact-resolving" type="checkbox" id="flexSwitchCheckDefault" style="width:40px;height: 21px;" <?php echo e($contact->status=="DONE"?"checked":""); ?> data-id="<?php echo e($contact->id); ?>">
							</div>
						 
					      </td>
					     <?php endif; // app('laratrust')->permission ?>
						<td>

							<?php if($contact->user_id!=null): ?>

	                        	<a href="<?php echo e(route('admin.users.show',$contact->user)); ?>" class="d-inline-block text-center">
	                                <img src="<?php echo e($contact->user->getUserAvatar()); ?>" style="width: 45px;height: 45px;display: inline-block;border-radius: 50%!important;padding: 3px;" class="mx-auto" alt="صورة المستخدم">
	                                <span style="display: inline-block;position: relative;top: 6px; " class="px-2 pt-0  text-start kufi"><?php echo e($contact->user->name); ?></span>
	                            </a> 
	                            <?php else: ?>
	                            
	                                <img src="https://manager.almadarisp.com/user/img/user.png" style="width: 45px;height: 45px;display: inline-block;border-radius: 50%!important;padding: 3px;" class="mx-auto" alt="صورة المستخدم">
	                                <span style="display: inline-block;position: relative;top: 6px; " class="px-2 pt-0  text-start kufi"><?php echo e($contact->name); ?><br><?php echo e($contact->email); ?><br><?php echo e($contact->phone); ?></span>

	                   
	                            <?php endif; ?>
						</td>
						<td><?php echo e(mb_strimwidth($contact->message,0,80,'...')); ?>

							<br>
							آخر رد من :
							<?php
							$last_reply= $contact->replies()->orderBy('id','DESC')->first();
							?>
							<?php if($last_reply!=null): ?>
								<?php echo e($last_reply->is_support_reply==1?"الدعم الفني":$contact->name); ?>

								<br>
								<?php echo e(mb_strimwidth($last_reply->content,0,80,'...')); ?>

							<?php else: ?>
							<?php echo e($contact->name); ?>

							<?php endif; ?>
							  
						</td>
					 
						<td style="width: 180px;">
							<?php if (app('laratrust')->isAbleTo('contacts-read',$contact)) : ?>
							<a href="<?php echo e(route('admin.contacts.show',$contact)); ?>">
							<span class="btn  btn-success btn-sm font-1 mx-1">
								<span class="fal fa-paper-plane"></span> مراسلة
							</span>
							</a>
							<?php endif; // app('laratrust')->permission ?>
							<?php if (app('laratrust')->isAbleTo('contacts-delete',$contact)) : ?>
							<form method="POST" action="<?php echo e(route('admin.contacts.destroy',$contact)); ?>" class="d-inline-block"><?php echo csrf_field(); ?> <?php echo method_field("DELETE"); ?>
								<button class="btn  btn-outline-danger btn-sm font-1 mx-1" onclick="var result = confirm('هل أنت متأكد من عملية الحذف ؟');if(result){}else{event.preventDefault()}">
									<span class="fas fa-trash "></span> حذف
								</button>
							</form>
							<?php endif; // app('laratrust')->permission ?>
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
			</div>
		</div>
		<div class="col-12 p-3">
			<?php echo e($contacts->appends(request()->query())->render()); ?>

		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php if (app('laratrust')->isAbleTo('resolve')) : ?>
<script type="text/javascript">
	$('.toggle-contact-resolving').on('change',function(){
		var id =$(this).attr('data-id');
		$.ajax({
		  method: "POST",
		  url: "<?php echo e(route('admin.contacts.resolve')); ?>",
		  data: { _token: "<?php echo e(csrf_token()); ?>", id: id }
		}).done(function(res){
			if(res.status=="DONE"){ 
				$('#ticket_'+id).addClass('ticket-resolved');
			}
			else{
				$('#ticket_'+id).removeClass('ticket-resolved');
			}
		});
	});
</script>
<?php endif; // app('laratrust')->permission ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\sites\dashboard\resources\views/admin/contacts/index.blade.php ENDPATH**/ ?>