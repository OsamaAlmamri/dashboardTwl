<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">





            <div class="">
                <div class="row">
                    <form action="#" method="post" class="row contact_form_box" id="RequestProject">

                        <div class="col-lg-12">


                            <div class="col-lg-12">
                                <h4 id="contact_div" class="text-center"><i class="fa fa-envelope"></i> طلب خدمة </h4>
                                <div id="sendmessage" class="text-center"><i class="fa fa-check-circle"></i>
                                                                        &nbsp;<?php echo e(trans('frontLang.youMessageSent')); ?></div>
                                    <div id="errormessage"
                                         class="text-center"><?php echo e(trans('frontLang.youMessageNotSent')); ?></div>
                                    

                                    <div class="col-lg-12">
                                        <div class="form-group text_box">
                                            <label>اختار الخدمة </label>
                                            <select class="form-control" name="ServiceName">
                                                <option value="دعاية واعلان">دعاية واعلان</option>
                                                <option value="تسوق">تسوق</option>
                                                <option value="انتاج مرئي وسمعي">انتاج مرئي وسمعي</option>
                                                <option value="تصوير">تصوير</option>
                                                <option value="برمجة">برمجة</option>
                                                <option value="التصميم">التصميم</option>
                                                <option value="ترجمة">ترجمة</option>
                                                <option value="اخرى ">اخرى</option>
                                            </select>


                                        </div>
                                        <div class="form-group text_box">
                                            <label>الإسم بالكامل</label>
                                            <input type="text" class="form-control" name="FullName" id="FullName"
                                                   placeholder="الإسم">
                                            


                                        </div>
                                        <div class="form-group text_box">
                                            <label>برجى كتابة بريدك الإلكتروني </label>
                                            
                                            <input type="email" class="form-control"  placeholder="البريد الإلكتروني"
                                                   name="email" id="email">

                                        </div>
                                        <div class="form-group text_box">
                                            <label>رقم الهاتف المحمول </label>
                                            
                                            
                                            <input placeholder="رقم الهاتف" class="form-control"  id="phone" data-rule="minlen:4" number=""
                                                   maxlength="10" minlength="10" name="phone" type="text" value="">


                                        </div>
                                        <div class="form-group text_box">
                                            <label>الأولوية</label>
                                            <select class="form-control" name="PriorityPhone">
                                                <option value="عالي">عالي</option>
                                                <option value="متوسط">متوسط</option>
                                                <option value="منخفض">منخفض</option>
                                            </select>


                                        </div>

                                        <div class="form-group text_box">
                                            <label>تفاصيل الطلب </label>
                                            
                                            <textarea placeholder="تفاصيل  الطلب " class="form-control" id="OrderDetail"
                                                      rows="2" data-rule="required" name="OrderDetail"
                                                      cols="50"></textarea>


                                        </div>
                                        
                                        

                                        

                                        

                                        
                                        
                                        
                                        
                                        
                                        

                                        <div class="input-group">

                                            <input placeholder="إنجاز الطلب من" id="FromDate" data-rule="minlen:4"
                                                   class="form-control date-picker"
                                                   name="FromDate" type="date" value="">

                                            <div class="input-group-addon">
                                                <span class="input-group-text" id="">الى</span>
                                            </div>
                                            <input placeholder="إنجاز الطلب  الى" id="ToDate" data-rule="required"
                                                   class="form-control date-picker" name="ToDate"
                                                   type="date" value="">
                                        </div>


                                    </div>
                                </div>
                            </div>













                                <div class="modal-footer">




                                    <button type="button" name="submit" class="btn_scroll btn_hover">إرسال الطلب
                                    </button>
                                    <button type="button" class="btn_scroll  btn-secondary btn-secondary"  data-bs-dismiss="modal">الغاء
                                    </button>
                                </div>



                            </div>
                        </div>
                    </form>
                </div>
            </div>

        </div>

    </div>
</div>


<?php /**PATH E:\sites\dashboardNouf\resources\views/components/ModalRequest.blade.php ENDPATH**/ ?>