
<?php $__env->startSection('content'); ?>
<div class="col-12 p-3">
	<div class="col-12 col-lg-12 p-0 main-box">
	 
		<div class="col-12 px-0">
			<div class="col-12 p-0 row">
				<div class="col-12 col-lg-4 py-3 px-3">
					<span class="fas fa-pages"></span> الصفحات
				</div>
				<div class="col-12 col-lg-4 p-0">
				</div>
				<div class="col-12 col-lg-4 p-2 text-lg-end">
					<?php if (app('laratrust')->isAbleTo('pages-create')) : ?>
					<a href="<?php echo e(route('admin.pages.create')); ?>">
					<span class="btn btn-primary"><span class="fas fa-plus"></span> إضافة جديد</span>
					</a>
					<?php endif; // app('laratrust')->permission ?>
				</div>
			</div>
			<div class="col-12 divider" style="min-height: 2px;"></div>
		</div>

		<div class="col-12 py-2 px-2 row">
			<div class="col-12 col-lg-4 p-2">
				<form method="GET">
					<input type="text" name="q" class="form-control" placeholder="بحث ... " value="<?php echo e(request()->get('q')); ?>">
				</form>
			</div>
		</div>
		<div class="col-12 p-3" style="overflow:auto">
			<div class="col-12 p-0" style="min-width:1100px;">
				
			
			<table class="table table-bordered  table-hover">
				<thead>
					<tr>
						<th>#</th>
						<th>المستخدم</th>
						<th>الرابط</th>
						<th>الشعار</th>
						<th>العنوان</th>
						<th>تحكم</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($page->id); ?></td>
						<td><?php echo e($page->user->name); ?></td>
						<td><?php echo e($page->slug); ?></td>
						<td><img src="<?php echo e($page->image()); ?>" style="width:40px"></td>
						<td><?php echo e($page->title); ?></td>
					 
						<td style="width: 270px;">

							<?php if (app('laratrust')->isAbleTo('pages-read')) : ?>
							<a href="<?php echo e(route('page.show',['page'=>$page])); ?>">
								<span class="btn  btn-outline-primary btn-sm font-1 mx-1">
									<span class="fas fa-search "></span> عرض
								</span>
							</a>
							<?php endif; // app('laratrust')->permission ?>

							<?php if (app('laratrust')->isAbleTo('pages-update')) : ?>
							<a href="<?php echo e(route('admin.pages.edit',$page)); ?>">
								<span class="btn  btn-outline-success btn-sm font-1 mx-1">
									<span class="fas fa-wrench "></span> تحكم
								</span>
							</a>
							<?php endif; // app('laratrust')->permission ?>
							<?php if (app('laratrust')->isAbleTo('pages-delete')) : ?>
							<form method="POST" action="<?php echo e(route('admin.pages.destroy',$page)); ?>" class="d-inline-block"><?php echo csrf_field(); ?> <?php echo method_field("DELETE"); ?>
								<button class="btn  btn-outline-danger btn-sm font-1 mx-1" onclick="var result = confirm('هل أنت متأكد من عملية الحذف ؟');if(result){}else{event.preventDefault()}">
									<span class="fas fa-trash "></span> حذف
								</button>
							</form>
							<?php endif; // app('laratrust')->permission ?>
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
			</div>
		</div>
		<div class="col-12 p-3">
			<?php echo e($pages->appends(request()->query())->render()); ?>

		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\sites\dashboard\resources\views/admin/pages/index.blade.php ENDPATH**/ ?>