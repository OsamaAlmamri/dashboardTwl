
<?php $__env->startSection('content'); ?>
<div class="container d-flex justify-content-end pt-4">
	<?php if(request()->get('user_id')!=null): ?>
	<?php if (app('laratrust')->isAbleTo('notifications-create')) : ?>
	<a href="<?php echo e(route('admin.notifications.create',['user_id'=>request()->get('user_id')])); ?>">
		<span class="btn btn-primary"><span class="fas fa-bells"></span> إرسال تنبيه</span>
	</a>
	<?php endif; // app('laratrust')->permission ?>
	<?php endif; ?>
</div>
<div class="col-12 container">
	<div class="col-12 p-3 notifications-container" >
		<?php if (isset($component)) { $__componentOriginalbdf04e36eb6b1458ab9aca210e828622d01957c5 = $component; } ?>
<?php $component = App\View\Components\Notifications::resolve(['notifications' => $notifications] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('notifications'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Notifications::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbdf04e36eb6b1458ab9aca210e828622d01957c5)): ?>
<?php $component = $__componentOriginalbdf04e36eb6b1458ab9aca210e828622d01957c5; ?>
<?php unset($__componentOriginalbdf04e36eb6b1458ab9aca210e828622d01957c5); ?>
<?php endif; ?>
	</div>
	<div class="col-12 p-3">
		<?php echo e($notifications->links()); ?>

	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\sites\dashboard\resources\views/admin/notifications/index.blade.php ENDPATH**/ ?>