<section class="wrapper bg-light  ">
    <div class="container  ">
        <div class="row gx-lg-8 gx-xl-12  align-items-center">
            <div class="col-lg-6 position-relative order-lg-2">


                <div class="overlap-grid overlap-grid-2">
                    <div class="item">
                        <figure class="rounded shadow"><img src="./storage/uploads/website/logo.png" alt=""></figure>
                    </div>
                    
                    
                    
                </div>
            </div>
            <!--/column -->
            <div class="col-lg-6">

                <h2 class="display-4 mb-2">
                    
                    <span class="far fa-info-circle mt-5" ></span>
                    من نحن؟</h2>

                <?php echo $settings->website_bio; ?>


                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                <!--/.row -->
            </div>
            <!--/column -->
        </div>
        <!--/.row -->
    </div>
    <!-- /.container -->
</section>
<?php /**PATH E:\sites\dashboardNouf\resources\views/components/about.blade.php ENDPATH**/ ?>