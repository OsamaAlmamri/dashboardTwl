
<?php $__env->startSection('content'); ?>
<div class="col-12 p-3">
	<div class="col-12 col-lg-12 px-2 ">
	 
		<div class="col-12 px-0 main-box">
			<div class="col-12 p-0 row">
				<div class="col-12 col-lg-4 py-3 px-3">
					عرض الكل
				</div>
				<div class="col-12 col-lg-4 p-2">
				</div>
				<div class="col-12 col-lg-4 p-2 text-lg-end">
					<?php if (app('laratrust')->isAbleTo('plugins-create')) : ?>
					<a href="<?php echo e(route('admin.plugins.create')); ?>">
					<span class="btn btn-primary"><span class="fas fa-plus"></span> إضافة جديد</span>
					</a>
					<?php endif; // app('laratrust')->permission ?>
				</div>
			</div>
			
		</div>
	</div>
		<div class="col-12 p-0">
			<?php
			$plugins = Module::all();
			?>
			<?php $__currentLoopData = $plugins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plugin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-12 col-md-6 col-lg-4 col-xxl-3 p-2 my-3">
				<div class="col-12 main-box p-3 text-center">
					<div class="col-12 p-1">
						<span class="<?php echo e($plugin->get('icon')); ?> font-10 my-3" style="color:<?php echo e($plugin->get('color')); ?>"></span>
					</div>
					<div class="col-12 p-0">
						<div class="col-12 p-0 font-2" style="font-weight:bold">
							<?php if($plugin->isEnabled()): ?> <span class="fas fa-check-circle text-success"></span> <?php endif; ?> <?php echo e($plugin->get('title')); ?>

						</div>
						<div class="col-12 px-0 py-3" style="text-align: justify;">
							<?php echo e($plugin->get('description')); ?>

						</div>
						<div class="col-12 px-0 py-3 text-center row" style="text-align: justify;">
							<?php if($plugin->isEnabled()): ?>
							<form method="POST" action="<?php echo e(route('admin.plugins.deactivate',['plugin'=>$plugin->get('name')])); ?>" class="d-inline-block mb-2 col-lg-12 col-12 p-1"><?php echo csrf_field(); ?>
								<button class="btn btn-outline-warning rounded-0 px-4" onclick="var result = confirm('هل أنت متأكد من عملية إلغاء تفعيل الإضافة؟');if(result){}else{event.preventDefault()}">
									الغاء تفعيل الإضافة
								</button>
							</form>
							<?php else: ?>
							<form method="POST" action="<?php echo e(route('admin.plugins.activate',['plugin'=>$plugin->get('name')])); ?>" class="d-inline-block mb-2 col-lg-12 col-12 p-1"><?php echo csrf_field(); ?>
								<button class="btn btn-outline-success rounded-0 px-4" onclick="var result = confirm('هل أنت متأكد من عملية تفعيل الإضافة؟');if(result){}else{event.preventDefault()}">
									تفعيل الإضافة
								</button>
							</form>
							<?php endif; ?>


							


						</div>
					</div>
					
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		
	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\sites\dashboard\resources\views/admin/plugins/index.blade.php ENDPATH**/ ?>