<section class="wrapper bg-light">
  <style type="text/css">
    .swiper-navigation{
      direction: ltr;
    }

  </style>
  <div class="overflow-hidden">
    <div class="container py-14 py-md-16">
      <div class="row">
        <div class="col-xl-7 col-xxl-6 mx-auto text-center">
          <i class="fal fa-pen-alt font-5"></i>
          <h2 class="display-5 text-center mt-2 mb-10">إليك أحدث مقالاتنا.</h2>
        </div>
        <!--/column -->
      </div>




      <!--/.row -->
      <div class="swiper-container nav-bottom nav-color mb-14"
           data-margin="30" data-dots="false" data-nav="true" data-items-lg="3" data-items-md="2" data-items-xs="1">
        <div class="swiper overflow-visible pb-2">
          <div class="swiper-wrapper">
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="swiper-slide">
                        <article>
                            <div class="card shadow-lg">
                                <figure class="card-img-top overlay overlay-1"><a href="<?php echo e(route('article.show',$article)); ?>"> <img src="<?php echo e($article->main_image()); ?>" alt="" style="height:280px !important;object-fit: cover;vertical-align: middle;" /></a>
                                    <figcaption>
                                        <h5 class="from-top mb-0 text-center">عرض المزيد</h5>
                                    </figcaption>
                                </figure>
                                <div class="card-body p-6">
                                    <div class="post-header">
                                        <div class="post-category">
                                            <?php $__currentLoopData = $article->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($loop->index<3): ?>
                                                    <a href="<?php echo e(route('category.show',$article_category)); ?>" class="hover" rel="category"><?php echo e($article_category->title); ?></a>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </div>
                                        <h3 class="post-title h3 mt-1 mb-3"><a class="link-dark" href="<?php echo e(route('article.show',$article)); ?>"><?php echo e($article->title); ?></a></h3>
                                    </div>
                                    <div class="post-footer">
                                        <ul class="post-meta d-flex mb-0">
                                            <li class="post-date">
		                      	<span>
		                      		<i class="fal fa-clock"></i>  <?php echo e(\Carbon::parse($article->created_at)->diffForHumans()); ?>

		                      	</span>
                                            </li>




                                            <?php if($article->comments_count!=0): ?>
                                                <li class="post-comments"><a href="#comments"><i class="fal fa-comment"></i> <?php echo e($article->comments_count); ?><span> تعليقات</span></a></li>
                                            <?php endif; ?>
                                            <?php if($article->views!=0): ?>
                                                <li class="post-comments"><a href="#comments"><i class="fas fa-fa-thin fa-eyes"></i> <?php echo e($article->views); ?><span> مشاهدة</span></a></li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </article>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<?php /**PATH E:\sites\dashboard\resources\views/components/our-blogs.blade.php ENDPATH**/ ?>