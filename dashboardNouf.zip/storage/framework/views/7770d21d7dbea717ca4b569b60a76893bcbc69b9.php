<section class="wrapper bg-light">






    <div class="position-relative">
      <div class="shape rounded-circle bg-soft-yellow rellax w-16 h-16" data-rellax-speed="1" style="bottom: 0.5rem; right: -1.7rem;"></div>
      <div class="shape rounded-circle bg-line red rellax w-16 h-16" data-rellax-speed="1" style="top: 0.5rem; left: -1.7rem;"></div>
      <div class="swiper-container dots-closer mb-6" data-margin="0" data-dots="true" data-items-xxl="2" data-items-lg="1" data-items-md="1" data-items-xs="1">
        <div class="swiper">
          <div class="swiper-wrapper">


              <?php $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="swiper-slide">
              <div class="item-inner">
                <div class="card p-0">
                  <div class="card-body p-0">
                    <img class="p-2"  src="<?php echo e($announcement->image()); ?>"  alt="" data-fancybox="gallery" />
                  </div>
                </div>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<?php /**PATH E:\sites\dashboardNouf\resources\views/components/slider1.blade.php ENDPATH**/ ?>