<?php

return [
    'name' => 'Team'
];
