<section class="wrapper bg-light dots2_left_background">
  <div class="container pb-5 pb-md-6 ">
    <h2 class="display-4 mb-3 text-center mt-5"> أوقات الدوام</h2>
    <div class="row">
      <div class="col-lg-12 mb-0">
        <div id="accordion-1" class="accordion-wrapper">

            {!! $settings->hourWorks !!}
        </div>
        <!-- /.accordion-wrapper -->
      </div>
      <!--/column -->

      <!--/column -->
    </div>
    <!--/.row -->
  </div>
  <!-- /.container -->
</section>
<!-- /section -->
